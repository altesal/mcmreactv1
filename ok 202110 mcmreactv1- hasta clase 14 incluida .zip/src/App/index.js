import React from 'react';
import { AppUI } from './AppUI';

/*
[{ text: 'La Pedrera de Gaudi', collection: true},
  { text: 'Parque Guell de Gaudi', collection: true},
  { text: 'Buzón de correos Casa del Arcediano, de Lluis Domênech i Muntaner', collection: false},
  { text: 'Catedral Barcelona', collection: false},
  { text: 'Jarrón de las gacelas', collection: false}]
*/

function useLocalStorage(itemName, initialValue) {
    const [error, setError] = React.useState(false);
    const [loading, setLoading] = React.useState(true);
    const [item, setItem] = React.useState(initialValue); //Tenemos un estado guardado (el de item) y un método para actualizarlo. Gracias a useState

    React.useEffect( () => {
      setTimeout(() => {
        try {
          const localStorageItem = localStorage.getItem(itemName);
          let parsedItem;
        
          if (!localStorageItem ) {
              localStorage.setItem(itemName, JSON.stringify(initialValue));
              parsedItem = initialValue;
          } else {
            parsedItem = JSON.parse(localStorageItem);
          }
  
          setItem(parsedItem);
          setLoading(false);
  
        } catch(error) {
          setError(error)
        }
      }, 2500);
    });

 
  const saveItem = (newItem) => {
   try{
    const stringifiedItem = JSON.stringify(newItem);
    localStorage.setItem(itemName, stringifiedItem);
    setItem(newItem);
   }
   catch(error) {
    setError(error)
   }
  };

  return {
    item,
    saveItem,
    loading,
  };
}



function App() {
 
const {
  item: stamps, 
  saveItem: saveStamps,
  loading,
  error,
} = useLocalStorage('STAMPS_V1', []);

  const [searchValue, setSearchValue] = React.useState('');

  const collectionStamps = stamps.filter(sello => !!sello.collection).length;
  const totalStamps = stamps.length;

  let searchedStamps = [];

  if (!searchValue.length  >= 1) {
    searchedStamps = stamps;
  } 
  else 
  {
    searchedStamps = stamps.filter(sello => {
      const stampText = sello.text.toLowerCase();
      const searchText = searchValue.toLowerCase();
      return stampText.includes(searchText);
    })
  }



const anadirStamps  = (text) => {
  const stampIndex = stamps.findIndex(stamp => stamp.text === text);
  
  const newStamps = [...stamps];
  newStamps[stampIndex].collection=true; 
    //stamps[stampIndex] = {
    //  text: stamps[stampIndex].text,
    //  collection: true,
    //};
    saveStamps(newStamps);  //--> Ejecuta un RE-RENDER
}

const deleteStamps = (text) => {
  const stampIndex = stamps.findIndex(stamp => stamp.text === text);
  const newStamps = [...stamps];
  newStamps.splice(stampIndex,1);
  saveStamps(newStamps);
}

/*
console.log('Render antes del use effect');
React.useEffect( () => {
  console.log('use effect');
}, [totalStamps]);
console.log('Render DESPUES del use effect');
*/
  return (
    <AppUI 
      loading={loading}
      error={error}
      totalStamps={totalStamps}
      collectionStamps = {collectionStamps }
      searchValue = {searchValue}
      setSearchValue = {setSearchValue}
      searchedStamps={searchedStamps}
      anadirStamps = { anadirStamps }
      deleteStamps = { deleteStamps }
    />
  );
}

export default App;
