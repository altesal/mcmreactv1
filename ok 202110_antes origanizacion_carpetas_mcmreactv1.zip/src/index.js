import React from 'react';
import ReactDOM from 'react-dom';   //para páginas webs
import './index.css';
import App from './App';


ReactDOM.render(
     <App />,
    document.getElementById('root')
);


