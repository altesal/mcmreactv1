import React from 'react';
import { StampContext } from '../StampContext';
import { StampCounter } from '../StampCounter';
import { StampSearch } from '../StampSearch';
import { StampList } from '../StampList';
import { CreateStampButton } from '../CreateStampButton';
import { StampItem } from '../StampItem';

function AppUI() {

    return (
<React.Fragment>
    <StampCounter />
    <StampSearch />
    <StampContext.Consumer>
        {({
            error, 
            loading,
            searchedStamps,
            anadirStamps,
            deleteStamps
        }) => (
            <StampList>
            {error && <p>Hubo un error...</p>}
            {loading && <p>Estamos cargando...</p>}
            {!loading && !searchedStamps.length  && <p>Añade el primer sello</p>}
    
            {searchedStamps.map(stamp => (
                  <StampItem 
                    key={stamp.text} 
                    text={stamp.text} 
                    collection={stamp.collection}
                    onCollection={ () => anadirStamps(stamp.text) }
                    onDelete={() => deleteStamps(stamp.text)}
                />
              ))}
            </StampList>        
        )}
        </StampContext.Consumer>
    <CreateStampButton />
</React.Fragment>

    );

}

export { AppUI };